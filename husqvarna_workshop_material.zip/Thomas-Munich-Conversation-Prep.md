# Conversation Prep: Thomas Weber - Munich Tender Loss

**Prepared**: February 12, 2026
**Context**: Lost Munich Parks tender to Stihl (third municipal tender loss this quarter)

---

## 1. SITUATION ANALYSIS

### What is the issue?
Lost the Munich Parks tender to Stihl. Customer feedback indicated:
- Stihl's local dealer had stronger relationships
- Our pricing was 8% higher
- Questions about our service response times

**Important context**: Thomas has already identified this in his Week 6 report and is planning a lessons-learned session. He's connected this to a broader pattern (3 municipal tenders lost to Stihl this quarter).

### Why does it matter?
- **Financial**: Lost a significant opportunity (was in negotiation stage with 1.9M EUR pipeline)
- **Strategic**: Reveals weakness in municipal/public sector channel strategy
- **Competitive**: Stihl is systematically winning in this segment through dealer relationships
- **Team morale**: Win rate is down to 31% (target 35%)

### What is your goal for this conversation?
✅ **DO**: Extract learnings, validate Thomas's strategic thinking, support him in addressing systemic issues
❌ **DON'T**: Make him feel blamed for structural problems (dealer network, pricing authority, service capacity)

**Success looks like**: Thomas feels supported to drive change; you both align on what needs to escalate vs. what he can control; concrete next steps identified.

---

## 2. PERSPECTIVE TAKING

### How might Thomas see this situation?
- **Frustrated**: This is the third loss in a pattern he's already flagged
- **Strategically aware**: He's identified root causes (dealer network, pricing authority limitations)
- **Proactive**: He's already planning lessons learned and asking for support
- **Slightly defensive**: He may worry you see this as his failure when he views it as a systemic issue

### What might he be feeling?
- **Validated**: He predicted this would keep happening without channel strategy changes
- **Concerned**: He's watching Stihl systematically outflank Husqvarna in public sector
- **Cautious optimism**: His Q1 forecast is still at 102%, so he's performing despite these losses
- **Possibly anxious**: Wondering if you'll blame him or actually help him fix the system

### What do you NOT know about their situation?
1. How much political capital has Thomas spent trying to get pricing authority increased?
2. Did he have specific intelligence about Stihl's dealer relationship in Munich beforehand?
3. What trade-offs did he make to keep overall pipeline at 102%?
4. How is the team reacting to these losses? (He mentions they're motivated, but is that the full picture?)
5. What alternatives did he explore during the tender process?

---

## 3. YOUR APPROACH

### Opening statement
**Recommended approach** (Direct but supportive):

> "Thomas, I wanted to talk with you about the Munich tender. I know you've already started the lessons-learned process, which I appreciate. I'm not here to second-guess your work – I want to understand what happened and how we can set you up to win these kinds of deals going forward. You've flagged this as the third municipal loss to Stihl's dealer network. Help me understand what you're seeing."

**Why this works**:
- Acknowledges he's already on it (not surprising him)
- Explicitly states you're not blaming
- Frames it as setting him up for success
- Asks for his expertise/insight

### Key points to cover

1. **Validate the pattern recognition**
   "You're right that this is becoming a pattern. Tell me about the dealer relationship issue – what exactly is Stihl doing that we're not?"

2. **Explore what's within his control vs. systemic**
   "Let's separate what you can influence directly from what needs my help or escalation. Where do you see the line?"

3. **Support his strategic asks**
   "You've asked for increased pricing authority and a channel strategy discussion. Let's talk about how we move those forward."

### Questions to ask

1. **"Help me understand the customer's decision process in Munich – what happened at each stage?"**
   *(Get details to understand if this was winnable with different tactics)*

2. **"You mentioned Stihl's dealer had stronger relationships. What does that look like in practice?"**
   *(Understand the competitor advantage precisely)*

3. **"If you had 100K EUR pricing authority instead of 50K, would that have changed the outcome?"**
   *(Test if his ask would solve the problem)*

4. **"What's working well in the deals you're winning? Hamburg Port looks promising."**
   *(Keep perspective on what's going right)*

5. **"What would you do differently if you could go back to the start of the Munich process?"**
   *(Learning focus, not blame)*

---

## 4. POTENTIAL RESPONSES & YOUR REPLIES

### If he becomes defensive:
**Response**: "I'm asking because I trust your judgment on the DACH market. You're seeing patterns I need to understand so we can make the right investments."

### If he blames pricing/systems:
**Response**: "You're right that there are structural issues here. Let's identify which ones we can tackle now and which need a longer runway. I want to support you, but I also need you to tell me what you can control in the meantime."

### If he shows frustration with repeated losses:
**Response**: "I hear that this is frustrating, especially when you saw it coming. That actually shows good market intelligence. Let's use that – what do you predict will happen in the next three tenders if we don't change approach?"

### If he questions whether you'll act on his feedback:
**Response**: "Fair question. Here's what I can commit to: [be specific]. For the bigger asks like channel strategy, I need to build the business case – help me understand what you need me to present to leadership."

---

## 5. COMMITMENT & FOLLOW-UP

### What specific commitments will you seek?

**From Thomas**:
1. Complete the lessons-learned session with team (already planned for next week)
2. Document specific dealer relationship advantages Stihl has in 2-3 recent losses
3. Propose what "good" looks like for dealer engagement in public sector
4. Identify next 2 municipal opportunities and strategy for winning them

**From you**:
1. Schedule channel strategy discussion within 2 weeks (include him)
2. Review pricing authority levels – bring proposal to leadership by [date]
3. Escalate spare parts issue with supply chain (get resolution timeline by [date])
4. Support his operations headcount request in Q2 planning

### How will you follow up?
- **Next week**: Check in after his lessons-learned session – "What came out of the debrief?"
- **Two weeks**: Channel strategy working session (include product, marketing)
- **Monthly**: Review municipal tender pipeline specifically

### What support will you offer?
1. **Political air cover**: "I'll take the channel strategy case to leadership"
2. **Resources**: Commit to exploring the operations headcount request
3. **Access**: "If you need me on a customer call to escalate, I'm available"
4. **Development**: "What would help you get even stronger at navigating these political/relationship-heavy deals?"

---

## FRAMING THIS AS LEARNING (Not Blame)

### Key principles for this conversation:

✅ **Acknowledge his pattern recognition**
He identified this three losses ago – validate that intelligence

✅ **Separate performance from systems**
His pipeline is at 102%; his win rate is down partly due to structural issues

✅ **Ask "what can we learn?" not "what went wrong?"**
Frame: "What does this tell us about municipal tenders?" not "Why did you lose?"

✅ **Share the responsibility**
"We haven't given you the right tools for this segment" vs. "You need to do better"

✅ **Focus forward, not backward**
"How do we win the next one?" is more valuable than "Why did we lose this one?"

✅ **Make it safe to be honest**
If you punish candor, you'll get excuses. If you reward insight, you'll get intelligence.

---

## RED FLAGS TO AVOID

❌ "What happened?" → Sounds like interrogation
✅ "Help me understand the customer's thinking"

❌ "This is the third one" → Sounds like blame accumulation
✅ "You've identified a pattern – let's address the root cause"

❌ "We can't afford to lose these" → Adds pressure, no solution
✅ "These matter. What do we need to change to win them?"

❌ "Why didn't you...?" → Implies he made mistakes
✅ "Walk me through your decision process"

---

## THOMAS'S STRENGTHS (Reference these)

Based on his Week 6 report:
- **Strategic thinking**: Connects individual losses to systemic issues
- **Proactive**: Planning lessons learned without being asked
- **Pipeline management**: Still at 102% despite losses
- **Team development**: Coaching Sandra, leveraging Klaus's strengths
- **Competitive intelligence**: Good awareness of Stihl, Ego, Deere moves
- **Candor**: Willing to ask for help and name problems

**Use in conversation**: "One thing I value about you is you don't just report problems – you analyze them. That's why I want your input on the solution."

---

## CONVERSATION FLOW SUGGESTION

1. **Open warmly** (1 min)
   "Thanks for the detailed report on Week 6. Before we talk Munich, how are you doing?"

2. **Frame as learning** (2 min)
   Use opening statement above

3. **Understand what happened** (10 min)
   Ask questions 1-3 above, listen more than talk

4. **Validate and contextualize** (5 min)
   "This makes sense given what you're up against. Here's what I'm hearing... [summarize]"

5. **Problem-solve together** (15 min)
   "Let's talk about what changes. What can you control? What do you need from me?"

6. **Commit to actions** (5 min)
   Be specific about who does what by when

7. **Reinforce confidence** (2 min)
   "You're doing strong work in a tough competitive environment. I'm backing you on this."

**Total: ~40 minutes**

---

## POST-CONVERSATION

### Document and share back:
Send Thomas a brief summary:
- What you both agreed happened
- Actions you're taking
- Actions he's taking
- Next check-in date

This shows you were listening and creates accountability.

---

**Remember**: Thomas is already doing the right things (analyzing, learning, asking for support). Your job is to validate that approach and remove barriers, not to make him feel like he failed.
