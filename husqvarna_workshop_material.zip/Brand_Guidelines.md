# Husqvarna Group - Brand Guidelines Summary

*Reference document for AI-generated content and communications*

---

## Brand Colors

| Color Name | Hex Code | Usage |
|------------|----------|-------|
| **Hot Cinnamon** (Orange) | `#E3671D` | Primary accent, CTAs, highlights |
| **Rhino** (Dark Blue) | `#273B60` | Headlines, primary text, backgrounds |
| **White** | `#FFFFFF` | Backgrounds, contrast text |
| **Light Grey** | `#F5F5F5` | Secondary backgrounds |
| **Dark Grey** | `#4A4A4A` | Body text |

### Color Psychology
- **Orange**: Energy, innovation, warmth, action - reflects the power and performance of products
- **Dark Blue**: Trust, expertise, stability, professionalism - reflects heritage and reliability
- **White**: Clarity, cleanliness, simplicity - reflects Scandinavian design principles

---

## Typography

### Primary Fonts
- **Headlines**: Husqvarna Gothic (proprietary) — Fallback: Roboto Condensed Bold
- **Body Text**: Roboto — Clean, modern, highly readable
- **Digital/Web**: Roboto, system fonts

### Typography Style
- Bold, confident headlines
- Clean, readable body copy
- Generous white space
- Clear hierarchy

---

## Brand Voice & Tone

### Personality Traits
1. **Pioneering** - Over 325 years of innovation
2. **Professional** - Expert-level quality and knowledge
3. **Sustainable** - Leading environmental responsibility
4. **Confident** - Market leader without arrogance
5. **Human** - Technology that serves people

### Tone Guidelines
- Direct and clear, not corporate jargon
- Confident but not boastful
- Technical when needed, accessible always
- Warm but professional
- Action-oriented

### Example Phrases
✓ "Pioneering solutions for outdoor environments"
✓ "Shaping great experiences"
✓ "Technology that works for you"
✗ "World-class synergies" (too corporate)
✗ "Disrupting the industry" (too startup)

---

## Core Values

### 1. Customer Focus
Delivering value to professionals and consumers through deep understanding of their needs.

### 2. Innovation
Pioneering new solutions - from the first commercial chainsaw to autonomous robotic mowers.

### 3. Sustainability
Leading the shift to battery-powered and robotic solutions. Science-based climate targets.

### 4. Performance
Results-driven culture with accountability. Quality in everything we do.

### 5. Collaboration
One company, many brands, shared purpose. Working together across boundaries.

---

## Brand Positioning

### Vision
"Shaping great experiences - through sustainable solutions that make outdoor environments and construction projects come to life"

### Mission
"To provide innovative products and services to professionals and consumers that increase productivity, improve quality of life, and are sustainable for people and the planet"

### Key Messages
1. **Heritage + Innovation**: 325+ years of pioneering
2. **Sustainability Leadership**: Leading the battery revolution
3. **Professional Excellence**: Trusted by professionals worldwide
4. **Complete Solutions**: Products, services, and support

---

## Visual Style

### Photography
- Real environments, authentic use cases
- Natural lighting preferred
- People at work (professionals) or enjoying results (consumers)
- Emphasis on nature and outdoor spaces
- Clean, uncluttered compositions

### Graphics & Icons
- Simple, functional design
- Consistent line weights
- Orange accent sparingly used
- Avoid decorative elements

### Layout Principles
- Generous white space
- Clear grid structure
- Strong visual hierarchy
- Mobile-first thinking

---

## Brand Architecture

### Corporate Brand
**Husqvarna Group** - The parent company

### Division Brands
1. **Husqvarna** - Forest & Garden (professional and prosumer)
2. **Gardena** - Home & Garden (consumer)
3. **Husqvarna Construction** - Professional construction equipment

### Supporting Brands
- Flymo, McCulloch, Weed Eater, Poulan Pro (regional/segment specific)

---

## Do's and Don'ts

### Do
- Use orange sparingly as an accent
- Maintain generous white space
- Keep messaging clear and direct
- Emphasize sustainability credentials
- Respect the heritage while being forward-looking

### Don't
- Overuse orange (it should pop, not dominate)
- Use trendy or fleeting design elements
- Make environmental claims without substance
- Forget the human element in technology stories
- Mix brand colors with off-brand alternatives

---

*Source: Compiled from public Husqvarna Group materials and brand assets.*
*For official brand guidelines, contact Husqvarna Group Communications.*
