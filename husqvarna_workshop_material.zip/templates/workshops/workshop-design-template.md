# Workshop Design Template

Use this template to design effective workshops and facilitated sessions.

---

## WORKSHOP OVERVIEW

| Field | Details |
|-------|---------|
| **Workshop Title** | |
| **Date & Time** | |
| **Duration** | |
| **Location/Platform** | |
| **Facilitator** | |
| **Number of Participants** | |

---

## 1. PURPOSE & OBJECTIVES

### Why are we doing this workshop?
*What problem are we solving or opportunity are we exploring?*

```
[Write here]
```

### What will participants walk away with?
*Be specific about deliverables and outcomes*

By the end of this workshop, participants will have:
1.
2.
3.

### How does this connect to broader goals?
*Link to team/division/company objectives*

```
[Write here]
```

---

## 2. PARTICIPANT ANALYSIS

### Who needs to be there?
| Role | Name | Why they're essential |
|------|------|----------------------|
| | | |
| | | |
| | | |

### What do they already know?
*Baseline knowledge and context*

```
[Write here]
```

### What concerns might they have?
*Anticipate resistance or skepticism*

```
[Write here]
```

---

## 3. PRE-WORK

### What should participants do before the workshop?

| Task | Time Required | Deadline |
|------|---------------|----------|
| | | |
| | | |

### Pre-work instructions to send:
```
[Draft email/message here]
```

---

## 4. DETAILED AGENDA

### Opening (10-15% of time)
| Time | Activity | Purpose | Materials |
|------|----------|---------|-----------|
| | Welcome & context | Set the stage | |
| | Icebreaker/check-in | Build connection | |
| | Agenda & ground rules | Align expectations | |

### Core Content (70-80% of time)
| Time | Activity | Purpose | Materials |
|------|----------|---------|-----------|
| | | | |
| | | | |
| | | | |
| | BREAK (5-10 min per hour) | | |
| | | | |
| | | | |

### Closing (10-15% of time)
| Time | Activity | Purpose | Materials |
|------|----------|---------|-----------|
| | Summary of key insights | Consolidate learning | |
| | Action planning | Drive commitment | |
| | Feedback & close | Continuous improvement | |

---

## 5. FACILITATION TECHNIQUES

### For Divergent Thinking (generating ideas):
- [ ] Brainstorming (silent first, then share)
- [ ] Round-robin input
- [ ] "What if..." prompts
- [ ] Worst idea exercise
- [ ] Inspiration from other industries

### For Convergent Thinking (making decisions):
- [ ] Dot voting
- [ ] 2x2 matrix (impact vs effort)
- [ ] Criteria-based ranking
- [ ] "Must have / Nice to have / Won't do"
- [ ] Decision matrix

### For Discussion:
- [ ] Think-Pair-Share
- [ ] Small group breakouts
- [ ] Fishbowl discussion
- [ ] Structured debate
- [ ] World Cafe

### For Energy & Engagement:
- [ ] Physical movement
- [ ] Change of scenery
- [ ] Music during activities
- [ ] Competition/gamification
- [ ] Storytelling

---

## 6. MATERIALS CHECKLIST

### Physical Workshop:
- [ ] Flip charts / whiteboards
- [ ] Post-it notes (multiple colors)
- [ ] Markers (thick for visibility)
- [ ] Dot stickers for voting
- [ ] Printed templates/handouts
- [ ] Timer (visible to all)
- [ ] Name tags
- [ ] Refreshments

### Virtual Workshop:
- [ ] Digital whiteboard (Miro, Mural, etc.)
- [ ] Breakout room setup
- [ ] Polls prepared
- [ ] Screen share materials ready
- [ ] Recording permission
- [ ] Backup plan for tech issues

---

## 7. RISK MITIGATION

| Potential Issue | Prevention/Response |
|-----------------|---------------------|
| Dominant voices | Use structured turn-taking, anonymous input |
| Low energy | Build in movement, vary activities |
| Going off-track | Park lot, time-keeper, redirect firmly |
| Conflict emerges | Acknowledge, ground rules, break if needed |
| Tech fails | Have backup plan, phone numbers |
| Running over time | Buffer in agenda, prioritize ruthlessly |

---

## 8. FOLLOW-UP PLAN

### Within 24 hours:
- [ ] Send thank you + summary
- [ ] Share photos/outputs
- [ ] Distribute action items

### Within 1 week:
- [ ] Finalize documentation
- [ ] Assign owners to actions
- [ ] Schedule follow-up check-in

### Ongoing:
- [ ] Track progress on commitments
- [ ] Address blockers
- [ ] Celebrate wins

---

## AI ASSISTANT PROMPTS

Use these prompts to get AI support for workshop design:

1. "Design a [duration] workshop on [topic] for [audience]. The goal is [objective]."

2. "What exercises would help a group [specific challenge]?"

3. "Create an icebreaker for a workshop about [topic] with [number] participants."

4. "How should I structure a strategy session to [outcome]?"

5. "What pre-work would help participants come prepared to discuss [topic]?"

6. "Suggest ways to make a virtual workshop on [topic] more engaging."

---

*Remember: A great workshop is 50% preparation, 30% facilitation, 20% follow-through.*
