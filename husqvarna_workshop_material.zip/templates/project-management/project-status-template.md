# Project Status Report Template

Use this template for weekly or bi-weekly project status updates.

---

## PROJECT OVERVIEW

| Field | Details |
|-------|---------|
| **Project Name** | |
| **Project Manager** | |
| **Sponsor** | |
| **Report Date** | |
| **Phase** | Planning / Execution / Closing |

---

## STATUS SUMMARY

### Overall Health: 🟢 Green / 🟡 Yellow / 🔴 Red

| Dimension | Status | Trend | Notes |
|-----------|--------|-------|-------|
| Schedule | 🟢/🟡/🔴 | ↑/→/↓ | |
| Budget | 🟢/🟡/🔴 | ↑/→/↓ | |
| Scope | 🟢/🟡/🔴 | ↑/→/↓ | |
| Resources | 🟢/🟡/🔴 | ↑/→/↓ | |
| Stakeholders | 🟢/🟡/🔴 | ↑/→/↓ | |

### Executive Summary (3-5 sentences)
```
[What's the overall situation? What should leadership know?]
```

---

## PROGRESS THIS PERIOD

### Completed
- [ ] Milestone/deliverable 1
- [ ] Milestone/deliverable 2
- [ ] Milestone/deliverable 3

### In Progress
| Activity | Owner | % Complete | Due Date |
|----------|-------|------------|----------|
| | | | |
| | | | |

### Planned for Next Period
1.
2.
3.

---

## SCHEDULE

### Key Milestones

| Milestone | Baseline Date | Current Date | Status |
|-----------|---------------|--------------|--------|
| | | | On track / At risk / Delayed |
| | | | |
| | | | |

### Timeline Risks
```
[Any schedule concerns or dependencies at risk?]
```

---

## BUDGET

| Category | Budget | Actual | Forecast | Variance |
|----------|--------|--------|----------|----------|
| Labor | | | | |
| External | | | | |
| Equipment | | | | |
| Other | | | | |
| **Total** | | | | |

### Budget Notes
```
[Explain any variances or concerns]
```

---

## RISKS & ISSUES

### Active Risks

| ID | Risk | Probability | Impact | Mitigation | Owner |
|----|------|-------------|--------|------------|-------|
| R1 | | H/M/L | H/M/L | | |
| R2 | | H/M/L | H/M/L | | |

### Open Issues

| ID | Issue | Impact | Action Required | Owner | Due |
|----|-------|--------|-----------------|-------|-----|
| I1 | | | | | |
| I2 | | | | | |

### Decisions Needed

| Decision | Options | Recommendation | Deadline | Decider |
|----------|---------|----------------|----------|---------|
| | | | | |

---

## STAKEHOLDER & COMMUNICATION

### Key Stakeholder Sentiment
| Stakeholder | Sentiment | Notes |
|-------------|-----------|-------|
| Sponsor | 😊/😐/😟 | |
| Steering Committee | 😊/😐/😟 | |
| End Users | 😊/😐/😟 | |
| Team | 😊/😐/😟 | |

### Communication Activities
- [ ] Steering committee update
- [ ] Team meeting
- [ ] Stakeholder newsletter
- [ ] Other: ___

---

## RESOURCE STATUS

### Team Capacity
| Role | Name | Allocation | Availability | Notes |
|------|------|------------|--------------|-------|
| | | | | |
| | | | | |

### Resource Concerns
```
[Any capacity issues, skill gaps, or conflicts?]
```

---

## LESSONS LEARNED (Ongoing)

### What's Working Well
-
-

### What Could Be Improved
-
-

---

## AI ASSISTANT PROMPTS

Use these prompts to get AI support for project management:

1. "Analyze this project status report. What are the biggest risks I should focus on?"

2. "I'm behind schedule on [milestone]. Help me create a recovery plan."

3. "Draft a stakeholder communication explaining why we're delayed and what we're doing about it."

4. "What questions should I be prepared to answer in the steering committee meeting?"

5. "Help me identify dependencies I might be missing in this project plan."

6. "This project is getting complex. Help me simplify the status update for executives."

---

*Remember: Status reports should inform, not just document. Focus on what stakeholders need to know and decide.*
