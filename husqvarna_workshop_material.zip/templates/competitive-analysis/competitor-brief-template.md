# Competitor Intelligence Brief Template

Use this template to structure competitive analysis and market intelligence.

---

## BRIEF OVERVIEW

| Field | Details |
|-------|---------|
| **Competitor** | |
| **Date** | |
| **Prepared by** | |
| **Urgency** | High / Medium / Low |
| **Distribution** | |

---

## EXECUTIVE SUMMARY

*2-3 sentences: What happened and why it matters*

```
[Write here]
```

---

## 1. RECENT DEVELOPMENTS

### What happened?
*Specific news, announcements, or observed changes*

| Date | Development | Source |
|------|-------------|--------|
| | | |
| | | |
| | | |

### Context
*Background that helps interpret these developments*

```
[Write here]
```

---

## 2. STRATEGIC IMPLICATIONS

### For our market position:
*How does this affect our competitive standing?*

```
[Write here]
```

### For our customers:
*Will customers' options or behaviors change?*

```
[Write here]
```

### For our strategy:
*Does this validate, challenge, or require adjustment to our plans?*

```
[Write here]
```

---

## 3. SWOT ANALYSIS (Competitor)

### Strengths (to respect)
-
-
-

### Weaknesses (to exploit)
-
-
-

### Opportunities (they may pursue)
-
-
-

### Threats (they pose to us)
-
-
-

---

## 4. RECOMMENDED ACTIONS

### Immediate (this week):
| Action | Owner | Deadline |
|--------|-------|----------|
| | | |

### Short-term (this quarter):
| Action | Owner | Deadline |
|--------|-------|----------|
| | | |

### Monitor:
*What should we keep watching?*

-
-
-

---

## 5. INFORMATION GAPS

### What we don't know:
*Questions that would help us respond better*

1.
2.
3.

### How we might find out:
*Legitimate intelligence-gathering approaches*

-
-
-

---

## COMPETITOR PROFILES - QUICK REFERENCE

### Stihl
- **Headquarters**: Waiblingen, Germany
- **Revenue**: ~6 billion EUR
- **Ownership**: Family-owned (private)
- **Key Strengths**: Dealer network, brand loyalty, professional trust
- **Strategy**: Aggressive battery expansion while protecting petrol heritage
- **Watch for**: Dealer exclusivity, battery platform developments

### Deere & Company
- **Headquarters**: Moline, Illinois, USA
- **Revenue**: ~50+ billion USD (much larger, diversified)
- **Ownership**: Public (NYSE: DE)
- **Key Strengths**: Scale, R&D, commercial relationships, autonomy tech
- **Strategy**: Autonomous everything, vertical integration
- **Watch for**: Entry into residential/small commercial

### Techtronic Industries (TTI)
- **Headquarters**: Hong Kong
- **Revenue**: ~13 billion USD
- **Ownership**: Public
- **Key Brands**: Milwaukee, Ryobi, Ego
- **Key Strengths**: Battery innovation, retail partnerships, speed
- **Strategy**: Dominate through battery platform, aggressive pricing
- **Watch for**: Ego expansion, retail exclusives

### Honda
- **Headquarters**: Tokyo, Japan
- **Revenue**: ~130 billion USD (diversified)
- **Ownership**: Public
- **Key Strengths**: Engine quality, reliability reputation
- **Weakness**: Slower on electrification in OPE
- **Watch for**: Electric pivot timing, potential partnerships

### Chinese Manufacturers (Greenworks, Positec/Worx)
- **Key Strengths**: Cost, speed, improving quality
- **Strategy**: Value positioning, OEM relationships
- **Watch for**: Quality improvements, brand building, market share gains

---

## MARKET TREND TRACKING

### Battery/Electric Transition
| Indicator | Current State | Trend |
|-----------|---------------|-------|
| EU regulations | Ban on petrol in parks (some cities) | Accelerating |
| California regulations | Phase-out by 2024 (small engines) | In effect |
| Consumer preference | Shifting to battery (convenience) | Growing |
| Professional adoption | Earlier stage, accelerating | Growing |

### Robotics
| Indicator | Current State | Trend |
|-----------|---------------|-------|
| Consumer adoption | ~5% of mowers sold | +16% YoY |
| Commercial adoption | Emerging | Early stage |
| Price points | Declining steadily | Democratizing |
| Technology (GPS-free) | Maturing | Enabling expansion |

### Connectivity/Smart
| Indicator | Current State | Trend |
|-----------|---------------|-------|
| Fleet management demand | Growing in professional | Strong |
| Smart home integration | Consumer expectation | Standard |
| Data services | Emerging revenue stream | Opportunity |

---

## AI ASSISTANT PROMPTS

Use these prompts to get AI support for competitive analysis:

1. "Summarize recent news about [competitor] and what it means for us"

2. "Compare our battery strategy to [competitor]'s approach"

3. "What threats does [competitor move] pose to our [segment/product]?"

4. "Prepare a briefing on [market trend] for my leadership team"

5. "What questions should we be asking about [competitor]'s strategy?"

6. "How might [competitor] respond if we [our planned action]?"

---

*Remember: Good competitive intelligence informs strategy; it doesn't drive it reactively.*
