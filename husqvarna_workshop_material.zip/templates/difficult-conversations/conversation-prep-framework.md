# Difficult Conversation Preparation Framework

Use this framework to prepare for challenging conversations with team members, peers, or stakeholders.

---

## 1. SITUATION ANALYSIS

### What is the issue?
*Describe the specific behavior, situation, or problem that needs to be addressed.*

```
[Write here]
```

### Why does it matter?
*What is the impact on the team, project, or organization?*

```
[Write here]
```

### What is your goal for this conversation?
*What outcome would success look like?*

```
[Write here]
```

---

## 2. PERSPECTIVE TAKING

### How might the other person see this situation?
*Consider their point of view, pressures, and constraints.*

```
[Write here]
```

### What might they be feeling?
*Anticipate emotional responses: defensive, anxious, confused, frustrated?*

```
[Write here]
```

### What do you NOT know about their situation?
*What questions should you ask before drawing conclusions?*

```
[Write here]
```

---

## 3. YOUR APPROACH

### Opening statement
*How will you start the conversation? (Direct but respectful)*

```
Example: "I wanted to talk with you about [topic] because [reason it matters].
I've noticed [specific observation] and I'd like to understand your perspective."
```

### Key points to cover
*Maximum 3 main points - be focused*

1.
2.
3.

### Questions to ask
*Open questions that invite dialogue*

1. "Help me understand..."
2. "What's been challenging about..."
3. "What would be helpful for you..."

---

## 4. POTENTIAL RESPONSES & YOUR REPLIES

### If they become defensive:
```
Response: "I'm not here to criticize. I want to understand what's happening
so we can find a path forward together."
```

### If they blame others:
```
Response: "I hear that there are other factors involved. Let's focus on what
we can control in this conversation - what's within your influence to change?"
```

### If they shut down:
```
Response: "I can see this is difficult. Would it help to take a short break
and continue this conversation tomorrow?"
```

### If they become emotional:
```
Response: "I can see this matters to you. Take a moment if you need it.
I want to have this conversation in a way that's productive for both of us."
```

---

## 5. COMMITMENT & FOLLOW-UP

### What specific commitments will you seek?
*Be concrete and time-bound*

```
[Write here]
```

### How will you follow up?
*When and how will you check in?*

```
[Write here]
```

### What support will you offer?
*What resources or assistance can you provide?*

```
[Write here]
```

---

## CONVERSATION TYPES - QUICK GUIDES

### Performance Discussion
- Lead with specific observations, not judgments
- Focus on behaviors and outcomes, not personality
- Connect to expectations and standards
- Offer support while maintaining accountability

### Delivering Unwelcome News
- Be direct - don't bury the lead
- Explain the "why" behind the decision
- Allow space for reaction
- Focus on what happens next

### Addressing Conflict
- Stay neutral if mediating
- Focus on interests, not positions
- Look for common ground
- Establish ground rules for dialogue

### Career Development (when expectations won't be met)
- Be honest about limitations
- Acknowledge their aspirations
- Explore alternatives together
- Maintain their dignity

---

## AI ASSISTANT PROMPTS

Use these prompts to get AI support for preparation:

1. "Help me prepare for a performance conversation with someone who [situation]"

2. "Role-play a conversation where I need to tell someone [difficult news]"

3. "What questions should I ask to understand why [problem] is happening?"

4. "How can I deliver this feedback in a way that's direct but supportive?"

5. "What are the potential reactions I should prepare for if I [action]?"

---

*Remember: The goal is a productive conversation, not winning an argument.*
