# Data Folder Structure

This folder contains reports and data for the AI Leadership Assistant demo.

## Structure

```
data/
├── reports/                    # Weekly reports from direct reports
│   ├── week-06/               # Reports for week 6, 2026
│   │   ├── product-development-nordics.md
│   │   ├── sales-operations-dach.md
│   │   ├── customer-support-europe.md
│   │   └── marketing-digital-global.md
│   └── week-07/               # (Future reports)
└── kpis/                      # Performance metrics and dashboards
```

## Report Format

Each weekly report follows a consistent structure:
- **Summary**: 2-3 sentence overview
- **Key Achievements**: What went well
- **Challenges & Blockers**: Issues needing attention
- **Team Status**: Individual and team health
- **Metrics**: Key performance indicators
- **Next Week Focus**: Priorities ahead
- **Support Needed**: Requests for leadership

## Demo Scenarios

### 1. Weekly Overview
Ask the AI to summarize all reports and identify priorities.

Example prompt:
> "Summarize this week's reports from my team. What should I focus on?"

### 2. Pattern Recognition
Ask the AI to identify themes across reports.

Example prompt:
> "What patterns do you see across my team's reports? Are there any systemic issues?"

### 3. Individual Focus
Deep dive into a specific report.

Example prompt:
> "I'm concerned about Claire's customer support report. What are the key issues and how should I address them?"

### 4. Action Planning
Get specific recommendations.

Example prompt:
> "Based on these reports, what are the top 3 actions I should take this week?"

---

*This is demo data for illustrative purposes.*
