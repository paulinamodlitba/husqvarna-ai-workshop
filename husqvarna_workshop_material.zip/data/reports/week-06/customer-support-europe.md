# Weekly Report: Customer Support - Europe

**Manager**: Claire Dubois
**Week**: 6 (Feb 3-7, 2026)
**Team Size**: 25 (15 agents, 6 technical specialists, 4 supervisors)

---

## Summary

High volume week due to the firmware update rollout. Call wait times exceeded targets but we managed without critical escalations. Team handled pressure well, but we need to improve our change communication process with product development.

---

## Key Achievements

1. **Firmware support handled** - 2,400 calls related to v2.3 update
2. **New knowledge base articles** - 12 articles published for common issues
3. **First-call resolution improved** - Up 3% to 72%
4. **Agent of the month** - Marco (Italy team) recognized for NPS scores

---

## Challenges & Blockers

### 1. Firmware Rollout Communication (HIGH)
We were not adequately briefed on the v2.3 update before it went live. Agents were learning alongside customers, which damaged credibility. Three customers explicitly complained about agent knowledge.

**Request**: Can we establish a mandatory 48-hour notice for any customer-facing changes?

### 2. Staffing for Peak Season (HIGH)
Spring season starts in 6 weeks. We need 8 temporary agents but HR approval is taking too long. If we don't start recruiting now, we won't have trained staff ready.

**Escalation**: Sent to HR (Lisa) on Tuesday - no response yet

### 3. 450X Battery Issues (MEDIUM)
Continuing to see elevated complaints about battery life on 450X units manufactured in Q3 2025. 47 cases this week alone. Engineering says it's "within spec" but customers disagree.

**Pattern**: Mostly units from the Huskvarna factory, serial numbers starting with HV25Q3

---

## Volume & Performance

| Metric | Target | Actual | vs Last Week |
|--------|--------|--------|--------------|
| Total contacts | 8,500 | 11,200 | +32% (firmware) |
| Avg wait time | <3 min | 4.2 min | Up |
| First-call resolution | 70% | 72% | Up |
| Customer satisfaction | 4.2/5 | 4.0/5 | Down |
| Escalation rate | <5% | 4.8% | Stable |

---

## Team Status

| Team | Status | Notes |
|------|--------|-------|
| Nordic | Green | Handling volume well |
| DACH | Yellow | Overtime concerns |
| France | Green | Strong performance |
| UK | Yellow | High attrition risk |
| Southern Europe | Green | Marco leading well |
| Technical Specialists | Red | Backlogged 3 days |

### Concerns:

**UK Team**: Two resignations in January, one more likely. Exit interviews cite pay gap vs market and limited career progression. We're losing experienced agents.

**Technical Specialists**: The firmware issues and 450X complaints have created a 3-day backlog. Customers waiting too long for complex case resolution.

---

## Top Issues This Week

| Issue | Volume | Trend | Notes |
|-------|--------|-------|-------|
| Firmware update questions | 2,400 | Spike | Expected to decline |
| 450X battery complaints | 47 | Stable | Need engineering input |
| App connectivity | 312 | Up | Android specific |
| Boundary wire breaks | 289 | Seasonal | Normal for Feb |
| Spare parts availability | 156 | Up | Supply chain issue |

---

## Customer Feedback Highlights

**Positive**:
> "The agent (Maria) was incredibly patient and walked me through every step. Best support experience I've had." - Customer in Sweden

**Negative**:
> "I called three times and got three different answers about the firmware update. Your team clearly wasn't trained." - Customer in Germany

> "Waiting 2 weeks for a replacement battery is not acceptable for a premium product." - Customer in UK

---

## Metrics

| Metric | Target | Actual | Trend |
|--------|--------|--------|-------|
| Agent utilization | 75% | 84% | Too high |
| Attrition rate | <15% | 22% | Concerning |
| Training hours/agent | 4/month | 2.5/month | Behind |
| Quality score | 90% | 88% | Stable |

---

## Next Week Focus

1. Debrief with Product Dev on firmware communication
2. Push HR for seasonal hiring approval
3. Deep-dive on UK retention issues
4. Technical specialist backlog - weekend overtime if needed

---

## Support Needed

1. **Change management process**: Need commitment from Product Dev on communication lead time
2. **Seasonal hiring approval**: Urgent - need 8 temps, budget already allocated
3. **UK retention**: Need HR support for market pay analysis
4. **450X battery escalation**: Need engineering to investigate serial number pattern

---

## Looking Ahead

The firmware spike will normalize, but I'm concerned about systemic issues:
- We're not getting advance notice of changes that impact customers
- UK team is at risk - we'll lose institutional knowledge if we don't act
- The 450X battery issue could become a larger problem

Spring season will test us. We need the seasonal staff approved this week.

---

*Submitted: Friday, Feb 7, 2026*
