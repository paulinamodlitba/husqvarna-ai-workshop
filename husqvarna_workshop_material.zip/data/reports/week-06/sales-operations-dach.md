# Weekly Report: Sales Operations - DACH Region

**Manager**: Thomas Weber
**Week**: 6 (Feb 3-7, 2026)
**Team Size**: 12 (4 account managers, 5 inside sales, 3 operations)

---

## Summary

Strong week for robotics pipeline - three new enterprise opportunities opened. However, we lost the Munich Parks tender to Stihl (price and local dealer relationship cited). Team is motivated but the competitive pressure is intensifying.

---

## Key Achievements

1. **Enterprise pipeline +3** - Hamburg Port, Siemens Campus, BASF Ludwigshafen
2. **Q1 forecast updated** - Currently at 102% of target
3. **Training completed** - All AMs certified on CEORA platform
4. **CRM cleanup** - 400+ dead opportunities archived

---

## Challenges & Blockers

### 1. Lost Munich Parks Tender (HIGH)
We were second choice. Feedback from the buyer:
- Stihl's local dealer had stronger relationships
- Our pricing was 8% higher
- They questioned our service response times

**My take**: This is the third municipal tender we've lost to Stihl's dealer network this quarter. We need to discuss our channel strategy for public sector.

### 2. Spare Parts Availability (MEDIUM)
Complaints from three key accounts about wait times for 450X parts. This is damaging our NPS and renewal conversations.

**Escalated to**: Supply chain (Markus) - awaiting response

### 3. Pricing Authority (MEDIUM)
I'm losing deals because I can't match competitor discounts without 3-day approval cycles. By then, the customer has decided.

**Request**: Can we discuss increased discount authority for deals >100K EUR?

---

## Pipeline Status

| Stage | Count | Value (M EUR) | vs Last Week |
|-------|-------|---------------|--------------|
| Qualified | 24 | 3.2 | +3 |
| Proposal | 18 | 2.8 | +1 |
| Negotiation | 8 | 1.9 | -1 (lost Munich) |
| Commit | 5 | 1.1 | Stable |

**Total Pipeline**: 55 opportunities, 9.0M EUR (target 8.5M)

---

## Team Status

| Name | Status | Notes |
|------|--------|-------|
| Klaus | Green | Top performer, 140% of target |
| Sandra | Yellow | Struggling with new accounts |
| Michael | Green | Strong on CEORA |
| Franziska | Green | |
| Inside Sales | Green | Good lead generation |
| Operations | Yellow | Overworked, need to discuss headcount |

**Sandra** needs coaching on consultative selling. She's working hard but not winning trust with enterprise buyers. I'm pairing her with Klaus for the next month.

---

## Competitive Intelligence

### Stihl
- Aggressive pricing on iMow in Germany
- New dealer incentive program launched
- Pushing "Buy German" messaging

### Ego (TTI)
- Pricing 15% below us on comparable products
- Expanding retail presence at OBI
- New commercial line announced for Q2

### John Deere
- Rumors of autonomous mower for mid-size commercial
- Heavy marketing in golf/sports turf segment

---

## Metrics

| Metric | Target | Actual | Trend |
|--------|--------|--------|-------|
| Pipeline coverage | 3.0x | 3.2x | Healthy |
| Win rate | 35% | 31% | Down |
| Avg deal size | 85K | 92K | Up |
| NPS (key accounts) | 45 | 38 | Concerning |

---

## Next Week Focus

1. Deep-dive on Munich loss - lessons learned session
2. Joint call with Klaus and Sandra (coaching)
3. Hamburg Port site visit - high potential
4. Quarterly business review prep

---

## Support Needed

1. **Channel strategy discussion**: Are we investing enough in dealer relationships for public sector?
2. **Pricing authority**: Can we increase my limit from 50K to 100K EUR?
3. **Spare parts escalation**: Need visibility on supply chain resolution
4. **Headcount**: Operations team needs +1 to handle volume

---

## Looking Ahead

Q1 is on track for target, but I'm worried about the competitive dynamics. Stihl is fighting hard in our core segments. We need to decide if we compete on price or differentiate on value. Trying to do both is exhausting the team.

---

*Submitted: Friday, Feb 7, 2026*
