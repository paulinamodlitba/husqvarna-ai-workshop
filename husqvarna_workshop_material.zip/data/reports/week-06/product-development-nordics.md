# Weekly Report: Product Development - Nordics

**Manager**: Erik Lindqvist
**Week**: 6 (Feb 3-7, 2026)
**Team Size**: 8 engineers

---

## Summary

Good progress on the X-Line battery platform integration. We hit our milestone for sensor calibration, but facing delays on the housing design from the supplier in Poland. Team morale is positive despite the overtime needed to meet the February deadline.

---

## Key Achievements

1. **Sensor calibration complete** - All 12 test units passed validation
2. **Firmware update deployed** - v2.3.1 now in testing phase
3. **Patent application submitted** - Navigation algorithm improvement
4. **New team member onboarded** - Sara started Monday, ramping up well

---

## Challenges & Blockers

### 1. Supplier Delay (HIGH)
The Polish supplier for the battery housing is 2 weeks behind. I've escalated to procurement, but we may need to consider alternatives. This could impact our March production start.

**Action needed**: Decision on whether to pay premium for expedited shipping or find backup supplier.

### 2. Testing Capacity (MEDIUM)
We're competing with the Gardena team for time in the test lab. Current booking is limiting our throughput.

**Proposed solution**: Can we discuss priority allocation for Q1?

### 3. Resource Conflict (LOW)
Anna has been pulled into the emergency fix for the 450X issue. Understandable, but it's affecting our timeline.

---

## Team Status

| Name | Status | Notes |
|------|--------|-------|
| Johan | Green | Leading firmware work |
| Maria | Yellow | Overloaded, needs support |
| Anders | Green | Strong progress |
| Lina | Green | Just returned from leave |
| Peter | Yellow | Some frustration with blockers |
| Karin | Green | |
| Oscar | Green | |
| Sara | Onboarding | Week 1 going well |

**Maria** is stretched thin - she's on three projects simultaneously. I'm concerned about burnout if this continues beyond February.

---

## Metrics

| Metric | Target | Actual | Trend |
|--------|--------|--------|-------|
| Sprint velocity | 45 pts | 42 pts | Stable |
| Bug backlog | <20 | 24 | Increasing |
| Test coverage | 85% | 82% | Stable |
| On-time delivery | 90% | 85% | Down |

---

## Next Week Focus

1. Resolve supplier issue - need decision by Wednesday
2. Complete integration testing for v2.3.1
3. Prepare demo for steering committee (Feb 14)
4. 1-on-1s with Maria and Peter to address workload concerns

---

## Support Needed

1. **Decision on supplier**: Expedite vs. backup (cost impact ~150K SEK)
2. **Lab time prioritization**: Can you discuss with Gardena leadership?
3. **Maria's workload**: Can we deprioritize one of her projects?

---

## Looking Ahead

February will be intense but manageable if we resolve the supplier issue this week. The team is committed but I'm watching for signs of fatigue. The March deadline is ambitious but achievable.

---

*Submitted: Friday, Feb 7, 2026*
